Snip Author
===========
David Rudie <d.rudie@gmail.com>

Contributors
============
* Kailan Blanks (TheKomputerKing)
  * Higher resolution album artwork from Spotify

* MindFlaw
  * French translation

* Azeirah
  * Dutch translation

* Lukas Michanek (SharpMelon)
  * Swedish translation

* Volker Königsbüscher
  * German translation

* Marks Polakovs (markspolakovs)
  * Unicode WebClient support
  * Updated artwork downloading for Spotify

* Erik Jan Meijer (Eegee)
  * Updated Dutch translations
  * Fix for VS project paths with spaces

* gummi
  * Norwegian translation

* TheLastRar & kamijoutouma
  * Crash fix for when titles too long

* Gonzalo Hidalgo (NioZero)
  * Spanish translation (es-CL)
  
* Bartosz Wiśniewski (PoprostuRonin)
  * Polish translation
  * VLC file extension filtering

* henryolik
  * Czech translation
  
* Stathis Galazios (nFin1ty)
  * Greek translation

* KingCrazy
  * Fix for VLC player trimming titles prematurely

* Jay Lapham (jaylapham)
  * Added support for Quod Libet player
  
* Jens Møller
  * Danish translation

* David (GenesisFR)
  * Determine if Spotify is playing an ad and empty files
  * Empty Snip.txt on exit
  * Refactored Settings.cs and Snip.cs
