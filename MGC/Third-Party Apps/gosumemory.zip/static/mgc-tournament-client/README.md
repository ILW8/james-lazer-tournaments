# mgc-tournament-client
A little note: some stuff done a little ugly since it's still WIP and cuz I based it off that client due to time limitations lol.
